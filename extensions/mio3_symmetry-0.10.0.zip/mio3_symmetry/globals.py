SUFFIX = [
    ("_L", "_R"),
    (".L", ".R"),
    ("-L", "-R"),
    ("Left", "Right"),
    ("_l", "_r"),
    (".l", ".r"),
    ("-l", "-r"),
]
NAME_ATTR_GROUP = "Mio3QS_UVGroup"
